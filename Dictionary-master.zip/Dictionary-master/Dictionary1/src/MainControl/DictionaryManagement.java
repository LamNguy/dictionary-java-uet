package MainControl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DictionaryManagement extends Dictionary {

    // look up a word
    public static String WordLookup( String word_find )
    {
        word_find = word_find.trim();
        try {
            if ( Dictionary.data.containsKey(word_find) )  return Dictionary.data.get(word_find);
        }
        catch (NullPointerException e){
            Utility.notification("Alt+Tab cause error");
        }
        Utility.notification("Word not existed");
        return "";
    }

    // add a new word
    public static void addWord(String new_word , String new_explain)
    {
        new_word = new_word.trim();
        if ( new_word.isEmpty()) {
            Utility.notification("Empty");
            return ;
        }
        if (data.containsKey(new_word))  Utility.notification("Word is exsited");
        else   {
            Utility.notification("Successful");
            data.put(new_word,new_explain) ;
            list.add(new_word) ;
            Collections.sort(list);
        }

    }

    // delete a word
    public static void DeleteWord(String word_find)
    {
        word_find = word_find.trim();
        if ( word_find.isEmpty()) {
            Utility.notification("Empty");
            return ;
        }
        if (data.containsKey(word_find)){
            data.remove(word_find);
            list.remove(word_find) ;
            Utility.notification("Successful");
        }
        else Utility.notification("Word is not existed");
    }

    // change meaning of a word
    public static void changeMeaningOfWord( String word_find, String word_change )
    {
        word_find = word_find.trim();
        if ( word_find.isEmpty()){
            Utility.notification("Empty");
            return ;
        }
        if ( data.containsKey(word_find))
        {
            data.remove(word_find);
            data.put(word_find,word_change) ;
            Utility.notification("Successful");
        }
       else Utility.notification("Word not found");
    }


    // search related words

    public  static List<String> dictionarySearcher(String word_find) {

        if  (word_find.trim().isEmpty()) return new ArrayList<>();
        int start = Collections.binarySearch(Dictionary.list , word_find);

        if (start < 0) {
            start = -start - 1;
        }

        int end = start;
        while (end < Dictionary.list.size() && Dictionary.list.get(end).startsWith(word_find)) end++;

        return Dictionary.list.subList(start,end) ;

    }
    // https://stackoverflow.com/questions/36525954/how-to-find-elements-that-start-with-a-sub-strings-inside-a-sorted-arraylist
}
