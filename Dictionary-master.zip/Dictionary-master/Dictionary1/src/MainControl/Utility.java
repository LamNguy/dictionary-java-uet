package MainControl ;

import javafx.scene.control.Alert;
import com.darkprograms.speech.synthesiser.SynthesiserV2;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.advanced.AdvancedPlayer;
import java.io.IOException;

public class Utility {
    private static  SynthesiserV2 synthesizer = new SynthesiserV2("AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw");

    // play sound
    public static void playSound(String text) {
        //Create a new Thread because JLayer is running on the current Thread and will make the application to lag
        Thread thread = new Thread(() -> {
            try {
                AdvancedPlayer player = new AdvancedPlayer(synthesizer.getMP3Data(text));
                player.play();
            } catch (IOException | JavaLayerException e) {

                e.printStackTrace(); //Print the exception ( we want to know , not hide below our finger , like many developers do...)
            }
        });
        //We don't want the application to terminate before this Thread terminates
        thread.setDaemon(false);
        //Start the Thread
        thread.start();

    }

    //  display status of signal
    public  static void notification(String message ){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.setTitle("Notice");
        ImageView image = new ImageView("image/assitant.png");
        image.setFitHeight(30);
        image.setFitWidth(30);
        alert.getDialogPane().setGraphic(image);
        ((Stage)alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("image/assitant.png"));
        alert.showAndWait();
    }

}
