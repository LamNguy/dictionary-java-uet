package MainControl;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

public class Dictionary {

    public   static TreeMap <String , String > data = new TreeMap<>() ;
    public   static List <String > list = new ArrayList<>();
}
