package MainControl;
import animatefx.animation.FadeIn;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage)  {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("../fxml/Dic.fxml"));
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("../fxml/style.css").toExternalForm());
            // set icon dictionary and name of program
            primaryStage.getIcons().add(new Image("image/icons8_Books_48px_3.png"));
            primaryStage.setTitle("Dictionary");
            primaryStage.setScene(scene);
            primaryStage.show();
            new FadeIn(root).play();
            primaryStage.setMaxHeight(642);
            primaryStage.setMaxWidth(929);
            primaryStage.setResizable(false);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        launch(args);

    }

}
