package fxml ;

import MainControl.DatabaseConnection;
import MainControl.Dictionary;
import MainControl.DictionaryManagement;
import MainControl.Utility;
import animatefx.animation.*;
import com.darkprograms.speech.microphone.Microphone;
import com.darkprograms.speech.recognizer.GSpeechDuplex;
import com.darkprograms.speech.recognizer.GSpeechResponseListener;
import com.darkprograms.speech.recognizer.GoogleResponse;
import com.darkprograms.speech.translator.GoogleTranslate;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import javafx.fxml.Initializable;
import javafx.scene.web.HTMLEditor;
import javafx.scene.web.WebView;
import net.sourceforge.javaflacencoder.FLACFileWriter;


import javax.sound.sampled.LineUnavailableException;

public class Controller implements Initializable {

   /*
    *----------------------------  FXML  ---------------------------------------
    */



    @FXML
    private Pane SearchPane, addPane, editPane, removePane, apiPane, infoPane, anchorPane, mainPane;

    @FXML
    private ImageView _searchIcon, addIcon, infoIcon, editIcon, removeIcon, apiIcon, soundApi1, soundApi2, stopIcon;

    @FXML
    private ImageView cfAddIcon, exitAddIcon, cfRemoveIcon, exitRemoveIcon, confirmEditButton, exitEditButton;

    // search items
    private Image searchPress = new Image("/image/icons8_Search_100px_2.png");
    private Image searchRelease = new Image("/image//icons8_Search_100px_1.png");
    // add items
    private Image addPress = new Image("image/icons8_Add_100px_1.png");
    private Image addRelease = new Image("image/icons8_Add_100px_2.png");
    // info items
    private Image infoPress = new Image("image/icons8_User_100px.png");
    private Image infoRelease = new Image("image/icons8_User_100px_1.png");
    // edit items
    private Image editPress = new Image("image/icons8_Edit_100px.png");
    private Image editRelease = new Image("image/icons8_Edit_96px_1.png");
    // remove items
    private Image removePress = new Image("image/icons8_Remove_100px_2.png");
    private Image removeRelease = new Image("image/icons8_Remove_100px_1.png");
    //  api item
    private Image apiPress = new Image("image/icons8_Translation_96px.png");
    private Image apiRelease = new Image("image/icons8_Language_96px_1.png");
    private Image soundApiPress = new Image("image/icons8_Foreign_Language_Sound_100px_1.png");
    private Image soundApiRelease = new Image ("image/icons8_Foreign_Language_Sound_100px.png");
    private Image stopIconPress = new Image("image/icons8_Stop_96px_1.png");
    private Image stopIconRelease = new Image("image/icons8_Stop_96px.png");
    // cf & cancel item
    private Image cancelIconPress = new Image("image/icons8_Delete_96px.png");
    private Image cfIconPress = new Image("image/icons8_Ok_96px.png");
    private Image cfIconRelease = new Image("image/icons8_Checked_96px.png");
    private Image cancelIconRelease = new Image("image/icons8_Cancel_96px.png");

    //--------------------------------------------------------------------------

    /*
     *  -------------------------------SEARCH------------------------------------
     */


    @FXML
    private TextField searchField;

    @FXML
    private WebView webView;

    @FXML
    private ListView<String> listView;

    /*
     * --------------------------------NEW WORD--------------------------------
     */

    @FXML
    private  TextField newWord ;

    @FXML
    private TextArea newMeaning ;

    /*
     *---------------------------------REMOVE------------------------------------
     */

    @FXML
    private TextField removeField ;

    /*
     *  --------------------------------EDIT-------------------------------------
     */

    @FXML
    private HTMLEditor editor ;

    @FXML
    private TextField newEditWord  ;

    /*
     *  ---------------------------GOOGLE TRANSLATE---------------------------------------
     */

    private static Microphone mic = new Microphone(FLACFileWriter.FLAC);

    private static GSpeechDuplex duplex = new GSpeechDuplex("AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw");

    private HashMap<String, String> LanguageCode = new HashMap<String, String>();

    private boolean _sourceLanguage = false ;

    private boolean _targetLanguage = false ;


    @FXML
    private ImageView Voice ;

    @FXML
    private TextArea input;

    @FXML
    private TextArea  output;

    @FXML
    private ComboBox sourceLanguage ;

    @FXML
    private ComboBox targetLanguage ;

    //-----------------------------------END-----------------------------------------



    /*--------------------------------------------------------------------------------
    ------------------------------ Initialize Data----------------------------------*/

    @Override // initialise program
    public void initialize(URL location, ResourceBundle resources) {
        loadDatabase();
        loadLanguage();
        listView.setVisible(false);
    }

    private void  loadDatabase() {
        Connection con = DatabaseConnection.getConnection();
        PreparedStatement st;
        ResultSet rs;
        String query = "SELECT word,detail FROM tbl_edict";
        try {
            st = con.prepareStatement(query);
            rs = st.executeQuery();

            while (rs.next()) {
                String word = rs.getString("word");
                String newWord = rs.getString("detail");
                newWord = newWord.substring(1);
                Dictionary.data.put(word,newWord);
            }
            Dictionary.list = new ArrayList<>(Dictionary.data.keySet());


            st.close();
            rs.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadLanguage(){
        ObservableList<String> sourceLanguageList = FXCollections.observableArrayList("English", "Vietnamese");
        ObservableList<String> targetLanguageList = FXCollections.observableArrayList("Chinese", "English", "Japanese", "Korean", "Vietnamese");

        sourceLanguage.setItems(sourceLanguageList);
        targetLanguage.setItems(targetLanguageList);
        LanguageCode.put("Vietnamese","vi");
        LanguageCode.put("English","en");
        LanguageCode.put("Japanese","ja");
        LanguageCode.put("Korean","ko");
        LanguageCode.put("Chinese","zh-CN");
    }


    /*-----------------------------------------------------------------------------------
    -----------------------------Switch panes animations--------------------------------------*/

    //------------------------------- search pane----------------------------------------
    public void searchPress() { _searchIcon.setImage(searchPress); }
    public void SearchRelease() {
        _searchIcon.setImage(searchRelease);
        if (SearchPane.getParent().getChildrenUnmodifiable().get(SearchPane.getParent().getChildrenUnmodifiable().size()-1) != SearchPane) {
            SearchPane.toFront();
            new FadeIn(SearchPane).play();
        }
    }

    //--------------------------------add pane------------------------------------------
    public void addPress() {
        addIcon.setImage(addPress);
    }
    public void addRelease() {
        addPane.setVisible(true);
       addIcon.setImage(addRelease);
        if (addPane.getParent().getChildrenUnmodifiable().get(addPane.getParent().getChildrenUnmodifiable().size()-1) != addPane) {
            addPane.toFront();
            new BounceInDown(addPane).play();
        }
    }
    public void cfAddIconPress() {cfAddIcon.setImage(cfIconPress);}
    public void exitAddIconPress() {exitAddIcon.setImage(cancelIconPress);}
    //-------------------------------edit pane------------------------------------------
    public void editPress() {
        editIcon.setImage(editPress);
    }
    public void editRelease() {
        editPane.setVisible(true);
        editIcon.setImage(editRelease);
        if (editPane.getParent().getChildrenUnmodifiable().get(editPane.getParent().getChildrenUnmodifiable().size()-1) != editPane) {
            editPane.toFront();
            new BounceInLeft(editPane).play();
        }
    }
    public void exitEditIconPress() {exitEditButton.setImage(cancelIconPress);}
    public void cfEditIconPress() {confirmEditButton.setImage(cfIconPress);}

    //-----------------------------remove pane------------------------------------------
    public void removePress() {
        removeIcon.setImage(removePress);
    }
    public void removeRelease() {
        removePane.setVisible(true);
        removeIcon.setImage(removeRelease);
        if (removePane.getParent().getChildrenUnmodifiable().get(removePane.getParent().getChildrenUnmodifiable().size()-1) != removePane) {
            removePane.toFront();
            new BounceInRight(removePane).play();
        }
    }
    public void exitRemoveIconPress() {exitRemoveIcon.setImage(cancelIconPress);}
    public void cfRemoveIconPress() { cfRemoveIcon.setImage(cfIconPress);}

    //------------------------------google translate pane--------------------------------
    public void apiPress() {
        apiIcon.setImage(apiPress);
    }
    public void apiRelease() {
        apiPane.setVisible(true);
        apiIcon.setImage(apiRelease);
        if (apiPane.getParent().getChildrenUnmodifiable().get(apiPane.getParent().getChildrenUnmodifiable().size()-1) != apiPane) {
            apiPane.toFront();
            new Tada(apiPane).play();
        }
    }
    public void soundApi1PressAction () { soundApi1.setImage(soundApiPress);}
    public void soundApi2PressAction() {soundApi2.setImage(soundApiPress);}
    public void stopIconPress() { stopIcon.setImage(stopIconPress);}

    //-----------------------------info pane---------------------------------------------
    public void infoPress() {
        infoIcon.setImage(infoPress);
    }
    public void infoRelease() {
        infoPane.setVisible(true);
        infoIcon.setImage(infoRelease);
        if (infoPane.getParent().getChildrenUnmodifiable().get(infoPane.getParent().getChildrenUnmodifiable().size()-1) != infoPane) {
            infoPane.toFront();
            new Wobble(infoPane).play();
        }
    }

    //-----------------------------------END--------------------------------------------



    /*
     *  ----------------------------- REMOVE ACTION CONTROL-----------------------------
     */

    // confirm remove word
    public void confirmRemoveButton(){
        cfRemoveIcon.setImage(cfIconRelease);
        DictionaryManagement.DeleteWord(removeField.getText());
        refreshListView();
        refreshRemoveWindow();
    }

    // refresh remove window
    public void refreshRemoveWindow(){
        exitRemoveIcon.setImage(cancelIconRelease);
        removeField.setText("");
        ultimateSearch();
    }

    /*
     *  -------------------------- SEARCH ACTION CONTROL --------------------------------
     */

    // display meaning when clicking
    public void clickMeaning(){
        searchField.setText(listView.getSelectionModel().getSelectedItem());
        webView.getEngine().loadContent(setFalseEditable( listView.getSelectionModel().getSelectedItem() ),"text/html");

    }

    // display meaning when scroll up and down
    public void moving(){
        clickMeaning();
    }

    // search related word
    public void ultimateSearch() {

        if (searchField.getText().trim().isEmpty()) {
            webView.getEngine().loadContent("");
            listView.setVisible(false);
            return ;
        }

        listView.setItems(FXCollections.observableArrayList(DictionaryManagement.dictionarySearcher(searchField.getText().trim())));
        listView.setVisible(true);


    }

    // When change word meaning , web view load an editable html text , so set it false
    private String setFalseEditable(String wordSelected ){
        String meaning = DictionaryManagement.WordLookup(wordSelected);
        if(meaning.contains("contenteditable=\"true\"")){
            meaning=meaning.replace("contenteditable=\"true\"", "contenteditable=\"false\"");
        }
        return meaning;
    }

    // Show meaning to Web view when press Search
    public void pressEnterSearch(KeyEvent event) {
        if (event.getCode() == KeyCode.ENTER) {
            webView.getEngine().loadContent(setFalseEditable( searchField.getText().trim()),"text/html");
        }
    }

    // play sound when press sound icon -- Type: ActionEvent
    public void getSound() {
        if ( !  Dictionary.list.contains(searchField.getText().trim()) || searchField.getText().isEmpty()) return ;
        Utility.playSound(searchField.getText().trim());
    }

    // refresh list view
    private void refreshListView(){
        webView.getEngine().loadContent("");
        searchField.setText("");
        ultimateSearch();
    }

    /*
     *  -------------------- --ADD ACTION CONTROL ----------------------------------------
     */

    // set editable text area if text field is not empty
    public void setMeaningEditable() {

        if (!newWord.getText().trim().isEmpty())
            newMeaning.setEditable(true);
        else {
            newMeaning.setEditable(false);
        }
    }

    // get HTML down line
    public void  getDownLine(KeyEvent e ){
        if ( e.getCode() == KeyCode.ENTER) {
            newMeaning.setText(newMeaning.getText() + "<br />");
        }
    }

    // confirm add new word
    public void confirmAddButton(){
        cfAddIcon.setImage(cfIconRelease);
        if ( newMeaning.getText().trim().isEmpty() && ! newWord.getText().trim().isEmpty()){
            Utility.notification("Set meaning");
            return ;
        }
        DictionaryManagement.addWord(newWord.getText().trim(),newMeaning.getText());
        refreshListView();
        refreshAddWindow();
    }

    // refresh window add new word
    public void refreshAddWindow(){
        exitAddIcon.setImage(cancelIconRelease);
        newMeaning.setText("");
        newWord.setText("");
        newMeaning.setEditable(false);

    }

    /*
     *  --------------------- EDIT ACTION CONTROL--------------------------------------  tat di
     */

    // set editable editor HTML if input is not empty
    public void setEditable() {
        if (newEditWord.getText().trim().isEmpty()) {
            editor.setHtmlText("");
            editor.setDisable(true);
        }
        else {
            getMeaningAuto();
            //editor.setDisable(false);
        }
    }

    // get meaning auto
    public void getMeaningAuto(){
        if (!Dictionary.list.contains(newEditWord.getText()) || newEditWord.getText().trim().isEmpty()) {
            editor.setHtmlText("");
            editor.setDisable(true);
            return ;
        }
        editor.setDisable(false);
        editor.setHtmlText(Dictionary.data.get(newEditWord.getText().trim()));
    }

    // confirm edit
    public void confirmEditButton(){
        confirmEditButton.setImage(cfIconRelease);
        DictionaryManagement.changeMeaningOfWord(newEditWord.getText(),editor.getHtmlText());
        editor.setDisable(true);
        refreshEditWindow();
        refreshListView();

    }

    // refresh edit window
    public void refreshEditWindow(){
        exitEditButton.setImage(cancelIconRelease);
        newEditWord.setText("");
        editor.setHtmlText("");
        editor.setDisable(true);
    }


    /*
     * --------------------------GOOGLE TRANSLATE ACTION CONTROL--------------------------
     */
    // get language code from another language
    private String getLanguageCode(String Language){
        return LanguageCode.get(Language);
    }

    // set translate when choose another language at source language Combo box --Type: ActionEvent
    public void chooseSourceLanguage() throws IOException {
        _sourceLanguage = true ;
        duplex.setLanguage(getLanguageCode(sourceLanguage.getValue().toString()));
        input.setText(GoogleTranslate.translate(getLanguageCode(sourceLanguage.getValue().toString()),input.getText()));
    }

    // set translate when choose another language at target language Combo box --Type: ActionEvent
    public void chooseTargetLanguage() throws IOException {
        _targetLanguage = true ;
        output.setText(GoogleTranslate.translate(getLanguageCode(targetLanguage.getValue().toString()),input.getText()));
    }

    // translate from input to output --Type: ActionEvent
    public void getSourceText() {

       // if ( input.getText().isEmpty()) return ;
        try {
            output.setText(GoogleTranslate.translate(getLanguageCode(sourceLanguage.getValue().toString()), getLanguageCode(targetLanguage.getValue().toString()), input.getText()));
        } catch (IOException ex) {
            ex.getStackTrace();
        } catch (NullPointerException exx){
            Utility.notification("Please set languages");
        }

    }

    // start recognising button
    public void controlVoice(){

        if ( ! checkCanSpeak()) {
            Utility.notification("Please set languages");
            return ;
        }
        Voice.setDisable(true);

        Utility.notification("Start recognising");
        duplex.addResponseListener(new GSpeechResponseListener() {
            public void onResponse(GoogleResponse googleResponse) {
                //Get the response from Google Cloud
                String output = googleResponse.getResponse().trim();
                if (output != null ) {

                    input.setText(googleResponse.getResponse());
                    getSourceText();

                } else
                    System.out.println("Output was null");
            }

        });
        startSpeechRecognition();

    }

    // stop recognising button
    public void disableVoice(){
        stopIcon.setImage(stopIconRelease);
        Voice.setDisable(false);
        input.setText("");
        output.setText("");
        stopSpeechRecognition();
    }

    // play sound in input area
    public void soundSource(){
        Utility.playSound(input.getText());
        soundApi1.setImage(soundApiRelease);
    }

    private boolean checkCanSpeak(){
        return _targetLanguage && _sourceLanguage;
    }

    // play sound in output area
    public void soundTarget(){
        Utility.playSound(output.getText());
        soundApi2.setImage(soundApiRelease);
    }

    // start recognising
    private void startSpeechRecognition() {
        //Start a new Thread so our application don't lags
        new Thread(()  -> {
            try {
                duplex.recognize(mic.getTargetDataLine(), mic.getAudioFormat());
            } catch (LineUnavailableException | InterruptedException e) {
                e.printStackTrace();
            }catch (IOException e) {
                e.printStackTrace();
            }
        }).start();

        }

    // stop recognising
    private void stopSpeechRecognition() {
        duplex.stopSpeechRecognition();
        mic.close();
        System.out.println("Stopping Speech Recognition...." + " , Microphone State is:" + mic.getState());
    }


    //----------------------------------- END ----------------------------------



}
